package com.example.penulisnovel;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ListViewHolder> {
    private final ArrayList<Novel> listNovel;
    public RecyclerViewAdapter(ArrayList<Novel> list){
        this.listNovel = list;
    }

    private OnItemClickCallback onItemClickCallback;

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback){
        this.onItemClickCallback = onItemClickCallback;
    }

    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.desain_layout_adapter, parent, false);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ListViewHolder holder, int position) {
        Novel novel = listNovel.get(position);
        holder.imgPhoto.setImageResource(novel.getFotoNovel());
        holder.novelNama.setText(novel.getNamaNovel());
        holder.nama.setText(novel.getNama());
        holder.deskripsi.setText(novel.getDeskripsi());

        holder.itemView.setOnClickListener(v -> onItemClickCallback.onItemClicked(listNovel.get(holder.getAdapterPosition())));
    }

    @Override
    public int getItemCount() {
        return listNovel.size();
    }

    public class ListViewHolder extends RecyclerView.ViewHolder {
        de.hdodenhof.circleimageview.CircleImageView imgPhoto;
        TextView novelNama, nama, deskripsi;


        public ListViewHolder(@NonNull View itemView) {
            super(itemView);
            imgPhoto = itemView.findViewById(R.id.view_image_novel);
            novelNama = itemView.findViewById(R.id.view_nama_novel);
            nama = itemView.findViewById(R.id.view_nama);
            deskripsi = itemView.findViewById(R.id.view_deskripsi);
        }
    }

    public interface OnItemClickCallback {
        void onItemClicked(Novel novel);
    }
}