package com.example.penulisnovel;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class DetailActivity extends AppCompatActivity {
    public static final String ITEM_EXTRA = "item_extra";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        ImageView foto_detail = findViewById(R.id.foto_detail);
        TextView detail_novel = findViewById(R.id.detail_novel);
        TextView detail_nama = findViewById(R.id.detail_nama);
        TextView detail_deskripsi = findViewById(R.id.deskripsi);


        Novel novel = getIntent().getParcelableExtra(ITEM_EXTRA);
        if (novel != null){
            Glide.with(this)
                    .load(novel.getFotoNovel())
                    .into(foto_detail);
            detail_novel.setText(novel.getNamaNovel());
            detail_nama.setText(novel.getNama());
            detail_deskripsi.setText(novel.getDeskripsi());
        }
        if (getSupportActionBar() != null){
            getSupportActionBar().setTitle("Detail Penulis");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

    }
    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }
}
