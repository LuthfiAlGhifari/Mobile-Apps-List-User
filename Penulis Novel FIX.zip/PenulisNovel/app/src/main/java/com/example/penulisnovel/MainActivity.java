package com.example.penulisnovel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvNovel;
    private ArrayList<Novel> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvNovel = findViewById(R.id.rv_novel);
        rvNovel.setHasFixedSize(true);

        list.addAll(getListNovel());
        showRecyclerList();

        if (getApplicationContext().getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){
            rvNovel.setLayoutManager(new GridLayoutManager( this, 2));
        } else{
            rvNovel.setLayoutManager(new LinearLayoutManager(this));
        }
    }

    public ArrayList<Novel> getListNovel(){
        String[] dataNamaNovel = getResources().getStringArray(R.array.nama_novel);
        String[] dataNama = getResources().getStringArray(R.array.nama);
        String[] dataDeskripsi = getResources().getStringArray(R.array.deskripsi);
        TypedArray dataFotoNovel = getResources().obtainTypedArray(R.array.fotoNovel);

        ArrayList<Novel> listNovel =new ArrayList<>();
        for (int i = 0; i < dataNamaNovel.length; i++){
            Novel novel = new Novel();
            novel.setNamaNovel(dataNamaNovel[i]);
            novel.setNama(dataNama[i]);
            novel.setDeskripsi(dataDeskripsi[i]);
            novel.setFotoNovel(dataFotoNovel.getResourceId(i, -1));

            listNovel.add(novel);
        }

        return listNovel;
    }

    private void showRecyclerList(){
        rvNovel.setLayoutManager(new LinearLayoutManager(this));
        RecyclerViewAdapter RecyclerViewAdapter= new RecyclerViewAdapter(list);
        rvNovel.setAdapter(RecyclerViewAdapter);

        RecyclerViewAdapter.setOnItemClickCallback(new RecyclerViewAdapter.OnItemClickCallback()
        {
            @Override
//          Mengirim Intent Explicit
            public void onItemClicked(Novel novel) {
                Intent moveIntent = new Intent(MainActivity.this, DetailActivity.class);
                moveIntent.putExtra(DetailActivity.ITEM_EXTRA, novel);
                startActivity(moveIntent);
            }
        });
    }
}