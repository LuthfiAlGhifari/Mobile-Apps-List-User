package com.example.penulisnovel;


import android.os.Parcel;
import android.os.Parcelable;

// Membuat Parcelable untuk transaksi antar data dari Novel ke Detail Activity
public class Novel implements Parcelable {
    private String namaNovel;
    private String nama;
    private String deskripsi;
    private Integer fotoNovel;


    protected Novel(Parcel in) {
        namaNovel = in.readString();
        nama = in.readString();
        deskripsi = in.readString();
        if (in.readByte() == 0){
            fotoNovel = null;
        } else{
            fotoNovel = in.readInt();
        }
    }

    public static final Creator<Novel> CREATOR = new Creator<Novel>() {
        @Override
        public Novel createFromParcel(Parcel in) { return new Novel(in); }

        @Override
        public Novel[] newArray(int size) { return new Novel[size]; }
    };

    public Novel(){

    }

    public String getNamaNovel() { return namaNovel; }

    public void setNamaNovel(String namaNovel) { this.namaNovel = namaNovel;}

    public String getNama() { return nama; }

    public void setNama(String nama) { this.nama = nama;}

    public String getDeskripsi() { return deskripsi; }

    public void setDeskripsi(String deskripsi) { this.deskripsi = deskripsi;}

    public Integer getFotoNovel() { return fotoNovel; }

    public void setFotoNovel(Integer fotoNovel) { this.fotoNovel = fotoNovel;}

    @Override
    public int describeContents() { return 0; }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(namaNovel);
            dest.writeString(nama);
            dest.writeString(deskripsi);
            if (fotoNovel == null){
                dest.writeByte((byte) 0);
            } else {
                dest.writeByte((byte) 1);
                dest.writeInt(fotoNovel);
            }
    }
}
